﻿using DidiFrame;
using DidiFrame.Application;
using DidiFrame.Culture;
using DidiFrame.Data;
using DidiFrame.Data.AutoKeys;
using DidiFrame.Data.Json;
using DidiFrame.DSharpAdapter;
using DidiFrame.GlobalEvents;
using DidiFrame.Logging;
using DidiFrame.UserCommands;
using DidiFrame.UserCommands.Loader.Reflection;
using FirstProject;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

//Step 1
var builder = DiscordApplicationBuilder.Create();

//Step 2
builder.AddJsonConfiguration("settings.json");

//Step 3
builder.AddLogging(logging => logging.SetMinimumLevel(LogLevel.Trace).AddFacnyConsoleLogging(builder.GetStartupTime()));

//Step 4
builder.AddServices(services => services
	//Add data management subsystem
	.AddJsonDataManagement(builder.GetConfiguration().GetSection("Data:Json"), true, true)
	//Add model factory provider
	.AddTransient<IModelFactoryProvider, DefaultModelFactoryProvider>()
	//Add auto repositories (optional)
	.AddAutoDataRepositories()
	//Add command repository
	.AddSimpleUserCommandsRepository()
	//Add command loader
	.AddReflectionUserCommandsLoader()
	//Add command pipeline
	.AddClassicMessageUserCommandPipeline(builder.GetConfiguration().GetSection("Commands:Parser"), builder.GetConfiguration().GetSection("Commands:Executer"))
	//Add discord client
	.AddDSharpClient(builder.GetConfiguration().GetSection("Discord"))

	.AddTransient<ICommandsModule, CommandModule>()
	.AddTransient<IModelFactory<HelloModel>, DefaultCtorModelFactory<HelloModel>>()
	//We added fancy console logging
	.AddColorfy()
	);

//Step 5
var application = builder.Build();

application.Connect();
await application.PrepareAsync();
await application.AwaitForExit();