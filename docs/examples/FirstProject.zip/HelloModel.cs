﻿using DidiFrame.Data.AutoKeys;
using DidiFrame.Data.Model;

namespace FirstProject
{
	[DataKey("hello")] //For auto repositories
	internal class HelloModel
	{
		public HelloModel(int helloCounter)
		{
			HelloCounter = helloCounter;
		}

		public HelloModel() : this(0) { }


		//Use attribute to assign from ctor
		[ConstructorAssignableProperty(0, "helloCounter")]
		public int HelloCounter { get; private set; }


		public void IncrementHelloCounter()
		{
			HelloCounter++;
		}
	}
}
