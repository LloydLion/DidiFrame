﻿using DidiFrame.Data;
using DidiFrame.Interfaces;
using DidiFrame.UserCommands.Loader.Reflection;
using DidiFrame.UserCommands.Models;

namespace FirstProject
{
	internal class CommandModule : ICommandsModule
	{
		private readonly IServersStatesRepository<HelloModel> repository;


		//Requests repository from di using auto repositories
		public CommandModule(IServersStatesRepository<HelloModel> repository)
		{
			this.repository = repository;
		}


		[Command("hello")]
		public UserCommandResult SayHello(UserCommandContext ctx, string word, IMember toMention)
		{
			//Do something here

			//Get and change state
			using var state = repository.GetState(ctx.Channel.Server);
			state.Object.IncrementHelloCounter();

			//Reutrn result with message
			var result = new UserCommandResult(UserCommandCode.Sucssesful) { RespondMessage = new($"Bot says hello to {toMention.Mention} with {word}") };
			return result;
		}

		[Command("print counter")] //Commands can be combained from 2 words (no more)
		public UserCommandResult PrintCounter(UserCommandContext ctx)
		{
			using var state = repository.GetState(ctx.Channel.Server);
			return new(UserCommandCode.Sucssesful) { RespondMessage = new($"Hello counter is {state.Object.HelloCounter}") };
		}
	}
}
